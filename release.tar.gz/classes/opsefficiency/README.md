# Review Point - Class Mapping

| Review Point | Concrete Class Implementation                           
|--------------|---------------------------------------------------------
| 4.1          | [ResourceMonitoring.py](ResourceMonitoring.py)
| 4.2          | [MetricAlarms.py](MetricAlarms.py)                 
| 4.3          | [ServiceLogs.py](ServiceLogs.py)
| 4.4          | [OperationsInsights.py](OperationsInsights.py)
| 4.5          | [CloudGuardEnabled.py](CloudGuardEnabled.py)
| 4.6          | [ConfigureAuditing.py](ConfigureAuditing.py)   
| 4.7          | [PatchesAndUpdates.py](PatchesAndUpdates.py)
                                  
